                                                 ---------------     WELCOME TO BOOKING SYSTEM APPLICATION     -------------
    

    NOTE:- DOWNLOAD ALL THE FILES ATTACHED BEFORE RUNNING THE PROGRAM.

  Select the desired option of admin or user( only  admin can make seats available for the next show if full)
  admin id -> admin
  password -> pass

                                                                      ACTION FOR USERS 
Select which action  you need to do by entering the desired number
   1.(EVENTS BOOKING) 
     TYPE 1 to display the name of cities.
       select your city by choosing the appropriate number ( we have taken a total of 4 cities DELHI MUMBAI BANGALORE KOLKATA).
       select the desired event.
         a)Movies-select the desired theater( EACH CITY HAS 4 THEATERS AND EACH THEATER HAS 4 MOVIES SO TOTAL MOVIES = 64)
           Select the desired movie to select the number of seats you want to book, if you are a user it will show you seats available select the desired seat number and then confirm. 
         b)Concerts-select desired concert( EACH CITY HAS 2 CONCERTS SO TOTAL CONCERTS=8)
           select the number of passes and then confirm it will show you the price and the serial number of the passes.
        
         c)Standups-select desired comedian (EACH CITY HAS 2 COMEDIANS SO TOTAL SHOWS- 8)
           select the number of passes and then confirm it will show you the price and the serial number of the passes.

    2.(INTER-CITY CAB BOOKING)
      select your current city by choosing the appropriate number ( we have taken a total of 4 cities DELHI MUMBAI BANGALORE KOLKATA).
      select your destination city by choosing the appropriate number ( we have taken a total of 4 cities DELHI MUMBAI BANGALORE KOLKATA).  
      select your desired vehicle( we have taken 5 types of vehicles based in seating space and luxury).
      it will show you the price for your destination according to the type of cab booked
  
    3.(RESTAURANT ORDERING)  
       Select veg or non-veg food for ordering(total 10 items for veg food and 10 items for non-veg foods)
           select food and quantity 
           select if you want to order more or to continue
           on confirming it will make a file where it will store the name, phone no and aderess of the user along with th grand total 
 


                                                                      ACTION FOR ADMIN 
       NOTE- an admin will make all the seats empty 
      Enter the ID and Password given above (i.e. id>>admin password>>pass)
      Select in which event you want to empty the  seats and then select the city 
      Select the desired theatre/event of which you want to make seats available.
       